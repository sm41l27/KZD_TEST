-- Read-only installation report; run after 000-004 in a new Supabase project.
with expected(name) as (values
 ('players'),('matches'),('match_players'),('moves'),
 ('kaz_social_profiles'),('kaz_friendships'),('kaz_messages'),('kaz_message_reads'),('kaz_game_invites'),
 ('kaz_tournaments'),('kaz_tournament_entries'),('kaz_tournament_matches'),('kaz_tournament_hidden')
)
select e.name as table_name,
  c.oid is not null as present,
  coalesce(c.relrowsecurity,false) as rls_enabled,
  coalesce(has_table_privilege('service_role',c.oid,'SELECT,INSERT,UPDATE,DELETE'),false) as server_access,
  coalesce(has_table_privilege('anon',c.oid,'SELECT,INSERT,UPDATE,DELETE'),false) as anon_access,
  coalesce(has_table_privilege('authenticated',c.oid,'SELECT,INSERT,UPDATE,DELETE'),false) as browser_access
from expected e left join pg_class c on c.oid=to_regclass('public.'||e.name)
order by e.name;

select name, to_regprocedure(name) is not null as present
from (values
 ('public.kaz_social(uuid,text,jsonb)'),
 ('public.kaz_tournament(uuid,text,jsonb)'),
 ('public.kaz_tournament_detail(uuid)'),
 ('public.kaz_tournament_room(uuid,uuid,text,jsonb)'),
 ('public.kaz_set_avatar(uuid,jsonb,text)')
) as expected(name);

select table_name,column_name,data_type
from information_schema.columns
where table_schema='public' and (table_name,column_name) in (
 ('matches','rating_mode'),('kaz_tournaments','ai_level'),
 ('kaz_social_profiles','avatar'),('kaz_tournament_matches','seats'),
 ('kaz_tournament_matches','game_started_at')
)
order by table_name,column_name;
