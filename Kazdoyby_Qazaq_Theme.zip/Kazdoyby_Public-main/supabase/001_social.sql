begin;
-- New tables only; existing players/matches and their policies are not changed.
create table if not exists public.kaz_social_profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 name text not null check(char_length(name) between 1 and 24),
 friend_code text not null unique default upper(substr(replace(gen_random_uuid()::text,'-',''),1,12)),
 updated_at timestamptz not null default now()
);
create table if not exists public.kaz_friendships (
 low_id uuid not null references auth.users(id) on delete cascade,
 high_id uuid not null references auth.users(id) on delete cascade,
 requester uuid not null references auth.users(id) on delete cascade,
 status text not null default 'pending' check(status in ('pending','accepted')),
 created_at timestamptz not null default now(),
 primary key(low_id,high_id), check(low_id<high_id), check(requester in(low_id,high_id))
);
create table if not exists public.kaz_messages (
 id bigint generated always as identity primary key,
 sender uuid not null references auth.users(id) on delete cascade,
 recipient uuid not null references auth.users(id) on delete cascade,
 body text not null check(char_length(btrim(body)) between 1 and 2000),
 nonce uuid not null, created_at timestamptz not null default now(),
 unique(sender,nonce), check(sender<>recipient)
);
create index if not exists kaz_messages_pair on public.kaz_messages(sender,recipient,id desc);
create index if not exists kaz_messages_recipient on public.kaz_messages(recipient,sender,id);
create table if not exists public.kaz_message_reads (
 reader uuid not null references auth.users(id) on delete cascade,
 peer uuid not null references auth.users(id) on delete cascade,
 last_id bigint not null default 0, primary key(reader,peer)
);
create table if not exists public.kaz_game_invites (
 id uuid primary key default gen_random_uuid(),
 sender uuid not null references auth.users(id) on delete cascade,
 recipient uuid not null references auth.users(id) on delete cascade,
 code text not null check(code ~ '^[A-Z0-9]{4,12}$'),
 status text not null default 'pending' check(status in('pending','accepted','declined')),
 created_at timestamptz not null default now(), expires_at timestamptz not null default now()+interval '10 minutes',
 check(sender<>recipient)
);
create index if not exists kaz_invites_recipient on public.kaz_game_invites(recipient,status,expires_at);
-- Only the existing trusted Node server may access these tables or call the RPC.
alter table public.kaz_social_profiles enable row level security;
alter table public.kaz_friendships enable row level security;
alter table public.kaz_messages enable row level security;
alter table public.kaz_message_reads enable row level security;
alter table public.kaz_game_invites enable row level security;
revoke all on public.kaz_social_profiles,public.kaz_friendships,public.kaz_messages,public.kaz_message_reads,public.kaz_game_invites from public,anon,authenticated;
grant all on public.kaz_social_profiles,public.kaz_friendships,public.kaz_messages,public.kaz_message_reads,public.kaz_game_invites to service_role;
grant usage,select on sequence public.kaz_messages_id_seq to service_role;

create or replace function public.kaz_social(p_actor uuid,p_action text,p_payload jsonb default '{}'::jsonb)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare
 target uuid; lo uuid; hi uuid; rel public.kaz_friendships%rowtype;
 inv public.kaz_game_invites%rowtype; result jsonb; cursor_id bigint; msg_id bigint;
begin
 if p_actor is null then raise exception 'SOCIAL:auth_required';end if;
 if p_action='init' then
   insert into public.kaz_social_profiles(id,name) values(p_actor,left(coalesce(nullif(btrim(p_payload->>'name'),''),'Ойыншы'),24))
   on conflict(id) do update set name=excluded.name,updated_at=now();
   return (select to_jsonb(p) from public.kaz_social_profiles p where id=p_actor);
 end if;
 if p_action='dashboard' then
   return jsonb_build_object(
    'profile',(select to_jsonb(p) from public.kaz_social_profiles p where id=p_actor),
    'friends',coalesce((select jsonb_agg(to_jsonb(x) order by x.name) from (
      select p.id,p.name,p.friend_code,f.status,f.requester,
       (select count(*) from public.kaz_messages m where m.sender=p.id and m.recipient=p_actor and m.id>coalesce((select last_id from public.kaz_message_reads where reader=p_actor and peer=p.id),0)) unread
      from public.kaz_friendships f join public.kaz_social_profiles p on p.id=case when f.low_id=p_actor then f.high_id else f.low_id end
      where p_actor in(f.low_id,f.high_id)
    ) x),'[]'::jsonb),
    'invites',coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at desc) from (
      select i.id,i.sender,i.code,i.created_at,i.expires_at,p.name
      from public.kaz_game_invites i join public.kaz_social_profiles p on p.id=i.sender
      join public.kaz_friendships f on f.low_id=least(i.sender,i.recipient) and f.high_id=greatest(i.sender,i.recipient) and f.status='accepted'
      where i.recipient=p_actor and i.status='pending' and i.expires_at>now() limit 30
    )x),'[]'::jsonb),
    'recent',coalesce((select jsonb_agg(to_jsonb(x) order by x.played_at desc) from (
      select other.auth_user_id id,coalesce(sp.name,other.name) name,sp.friend_code,max(m.started_at) played_at
      from (select mp.match_id,mp.color from public.match_players mp join public.players me on me.id=mp.player_id where me.auth_user_id=p_actor order by mp.match_id desc limit 30) own
      join public.matches m on m.id=own.match_id
      join public.match_players opponent on opponent.match_id=m.id and opponent.player_type='human'
      join public.players other on other.id=opponent.player_id
      left join public.kaz_social_profiles sp on sp.id=other.auth_user_id
      where other.auth_user_id is not null and other.auth_user_id<>p_actor
       and (m.game_mode<>'teams' or ((own.color in('blue','black'))<>(opponent.color in('blue','black'))))
      group by other.auth_user_id,coalesce(sp.name,other.name),sp.friend_code order by max(m.started_at) desc limit 20
    )x),'[]'::jsonb)
   );
 end if;
 if p_action='search' then
   if char_length(btrim(coalesce(p_payload->>'query','')))<2 then return '[]'::jsonb;end if;
   return coalesce((select jsonb_agg(to_jsonb(x)) from (
    select p.id,p.name,p.friend_code from (
     select sp.id,sp.name,sp.friend_code from public.kaz_social_profiles sp
     union all select pl.auth_user_id,pl.name,null::text from public.players pl
     where pl.auth_user_id is not null and not exists(select 1 from public.kaz_social_profiles sp where sp.id=pl.auth_user_id)
    ) p
    where p.id<>p_actor and (upper(p.friend_code)=upper(btrim(p_payload->>'query')) or position(lower(btrim(p_payload->>'query')) in lower(p.name))>0)
    order by (upper(p.friend_code)=upper(btrim(p_payload->>'query'))) desc,p.name,p.id limit 20
   )x),'[]'::jsonb);
 end if;
 if p_action in('invitation','decline','joined') then
   select * into inv from public.kaz_game_invites where id=(p_payload->>'id')::uuid and recipient=p_actor for update;
   if not found or inv.status<>'pending' or inv.expires_at<=now() then raise exception 'SOCIAL:invite_expired';end if;
   if not exists(select 1 from public.kaz_friendships where low_id=least(inv.sender,p_actor) and high_id=greatest(inv.sender,p_actor) and status='accepted')then raise exception 'SOCIAL:not_friends';end if;
   if p_action<>'invitation' then update public.kaz_game_invites set status=case when p_action='joined' then 'accepted' else 'declined' end where id=inv.id;end if;
   return to_jsonb(inv)||jsonb_build_object('peer',inv.sender);
 end if;
 target=(p_payload->>'target')::uuid;
 if target is null or target=p_actor then raise exception 'SOCIAL:invalid';end if;
 lo=least(p_actor,target);hi=greatest(p_actor,target);
 -- Serializes opposite requests, acceptance, removal and message sends for this pair.
 perform pg_advisory_xact_lock(hashtextextended(lo::text||hi::text,0));
 select * into rel from public.kaz_friendships where low_id=lo and high_id=hi for update;
 if p_action='request' then
   if not exists(select 1 from public.kaz_social_profiles where id=target) then
    insert into public.kaz_social_profiles(id,name) select auth_user_id,left(name,24) from public.players where auth_user_id=target limit 1 on conflict(id) do nothing;
   end if;
   if not exists(select 1 from public.kaz_social_profiles where id=target)then raise exception 'SOCIAL:not_found';end if;
   insert into public.kaz_friendships(low_id,high_id,requester)values(lo,hi,p_actor)on conflict do nothing;
   return jsonb_build_object('peer',target);
 elsif p_action='accept' then
   if rel.status is distinct from 'pending' or rel.requester=p_actor then raise exception 'SOCIAL:invalid';end if;
   update public.kaz_friendships set status='accepted' where low_id=lo and high_id=hi;
   return jsonb_build_object('peer',target);
 elsif p_action='remove' then
   delete from public.kaz_friendships where low_id=lo and high_id=hi;
   update public.kaz_game_invites set status='declined' where sender in(lo,hi) and recipient in(lo,hi) and status='pending';
   return jsonb_build_object('peer',target);
 end if;
 if rel.status is distinct from 'accepted' then raise exception 'SOCIAL:not_friends';end if;
 if p_action='messages' then
   cursor_id=nullif(p_payload->>'before','')::bigint;
   return coalesce((select jsonb_agg(to_jsonb(x) order by x.sort_id) from (
     select id::text id,id sort_id,sender,recipient,body,nonce,created_at from public.kaz_messages
     where ((sender=p_actor and recipient=target)or(sender=target and recipient=p_actor)) and(cursor_id is null or id<cursor_id)
     order by id desc limit 50
   )x),'[]'::jsonb);
 elsif p_action='send' then
   insert into public.kaz_messages(sender,recipient,body,nonce)values(p_actor,target,btrim(p_payload->>'body'),(p_payload->>'nonce')::uuid)
   on conflict(sender,nonce)do nothing returning id into msg_id;
   if msg_id is null then select id into msg_id from public.kaz_messages where sender=p_actor and nonce=(p_payload->>'nonce')::uuid and recipient=target;end if;
   if msg_id is null then raise exception 'SOCIAL:invalid';end if;
   return(select to_jsonb(m)||jsonb_build_object('id',m.id::text) from public.kaz_messages m where id=msg_id);
 elsif p_action='read' then
   select coalesce(max(id),0) into cursor_id from public.kaz_messages where recipient=p_actor and sender=target and id<=coalesce((p_payload->>'last')::bigint,0);
   insert into public.kaz_message_reads(reader,peer,last_id)values(p_actor,target,cursor_id)on conflict(reader,peer)do update set last_id=greatest(kaz_message_reads.last_id,excluded.last_id);
   return '{}'::jsonb;
 elsif p_action='invite' then
   select * into inv from public.kaz_game_invites where sender=p_actor and recipient=target and code=p_payload->>'code' and status='pending' and expires_at>now() limit 1;
   if not found then insert into public.kaz_game_invites(sender,recipient,code)values(p_actor,target,p_payload->>'code')returning * into inv;end if;
   return to_jsonb(inv);
 end if;
 raise exception 'SOCIAL:invalid';
end;
$$;
revoke all on function public.kaz_social(uuid,text,jsonb) from public,anon,authenticated;
grant execute on function public.kaz_social(uuid,text,jsonb) to service_role;
notify pgrst,'reload schema';
commit;
