-- Apply AFTER 001_social.sql. New tables are private; Node is the only RPC caller.
begin;
alter table public.matches add column if not exists rating_mode text not null default 'rated';

create table if not exists public.kaz_tournaments (
 id uuid primary key default gen_random_uuid(),
 code text not null unique default upper(substr(replace(gen_random_uuid()::text,'-',''),1,8)),
 owner_id uuid not null references auth.users(id) on delete cascade,
 name text not null check (char_length(name) between 3 and 60),
 capacity integer not null check (capacity in (2,4,8,16)),
 time_control integer not null default 600 check (time_control in (180,300,600,900)),
 status text not null default 'registration' check (status in ('registration','running','completed','cancelled')),
 winner_id uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now(), started_at timestamptz, finished_at timestamptz
);
create table if not exists public.kaz_tournament_entries (
 tournament_id uuid not null references public.kaz_tournaments(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 name text not null, joined_at timestamptz not null default now(), seed integer,
 primary key(tournament_id,user_id), unique(tournament_id,seed)
);
create table if not exists public.kaz_tournament_matches (
 id uuid primary key default gen_random_uuid(),
 tournament_id uuid not null references public.kaz_tournaments(id) on delete cascade,
 round integer not null check(round between 1 and 4), slot integer not null,
 player1 uuid references auth.users(id) on delete set null,
 player2 uuid references auth.users(id) on delete set null,
 winner_id uuid references auth.users(id) on delete set null,
 status text not null default 'pending' check(status in ('pending','ready','playing','finished')),
 room_code text, attempts integer not null default 0,
 unique(tournament_id,round,slot)
);
create index if not exists kaz_tournament_entries_user on public.kaz_tournament_entries(user_id,tournament_id);
create index if not exists kaz_tournaments_owner on public.kaz_tournaments(owner_id,created_at desc);
alter table public.kaz_tournaments enable row level security;
alter table public.kaz_tournament_entries enable row level security;
alter table public.kaz_tournament_matches enable row level security;
revoke all on public.kaz_tournaments,public.kaz_tournament_entries,public.kaz_tournament_matches from public,anon,authenticated;
grant select,insert,update,delete on public.kaz_tournaments,public.kaz_tournament_entries,public.kaz_tournament_matches to service_role;

create or replace function public.kaz_tournament_detail(p_id uuid) returns jsonb
language sql security invoker set search_path=public,pg_temp as $$
 select to_jsonb(t) || jsonb_build_object(
   'entries',coalesce((select jsonb_agg(to_jsonb(e) order by e.seed nulls last,e.joined_at) from kaz_tournament_entries e where e.tournament_id=t.id),'[]'::jsonb),
   'matches',coalesce((select jsonb_agg(to_jsonb(m) order by m.round,m.slot) from kaz_tournament_matches m where m.tournament_id=t.id),'[]'::jsonb)
 ) from kaz_tournaments t where t.id=p_id
$$;
revoke all on function public.kaz_tournament_detail(uuid) from public,anon,authenticated;
grant execute on function public.kaz_tournament_detail(uuid) to service_role;

create or replace function public.kaz_tournament(p_actor uuid,p_action text,p_payload jsonb default '{}'::jsonb) returns jsonb
language plpgsql security invoker set search_path=public,pg_temp as $$
declare
 v_id uuid; v_t kaz_tournaments; v_m kaz_tournament_matches; v_next kaz_tournament_matches;
 v_users uuid[]; v_n integer; v_round integer; v_slot integer; v_size integer; v_win uuid;
 v_name text; v_code text;
begin
 if p_actor is null then raise exception 'ARENA:auth_required'; end if;
 if p_action='list' then
   return coalesce((select jsonb_agg(x.data order by x.created_at desc) from (
     select to_jsonb(t)||jsonb_build_object('joined',(select count(*) from kaz_tournament_entries e where e.tournament_id=t.id)) data,t.created_at
     from kaz_tournaments t where t.owner_id=p_actor or exists(select 1 from kaz_tournament_entries e where e.tournament_id=t.id and e.user_id=p_actor)
     order by t.created_at desc limit 30
   ) x),'[]'::jsonb);
 end if;
 if p_action='create' then
   v_name:=left(trim(coalesce(p_payload->>'name','')),60);
   if char_length(v_name)<3 or (p_payload->>'capacity')::integer not in (2,4,8,16) or (p_payload->>'time')::integer not in (180,300,600,900) then raise exception 'ARENA:invalid'; end if;
   perform pg_advisory_xact_lock(hashtextextended(p_actor::text,12));
   if (select count(*) from kaz_tournaments where owner_id=p_actor and status in ('registration','running')) >= 5 then raise exception 'ARENA:limit'; end if;
   insert into kaz_tournaments(owner_id,name,capacity,time_control) values(p_actor,v_name,(p_payload->>'capacity')::integer,(p_payload->>'time')::integer) returning id into v_id;
   insert into kaz_tournament_entries(tournament_id,user_id,name) values(v_id,p_actor,coalesce(nullif(left(trim(p_payload->>'playerName'),24),''),'Ойыншы'));
   return kaz_tournament_detail(v_id);
 end if;
 if p_action in ('match','bind','result') then
   select tournament_id into v_id from kaz_tournament_matches where id=(p_payload->>'match')::uuid;
 else
   select id into v_id from kaz_tournaments where id=nullif(p_payload->>'id','')::uuid or code=upper(p_payload->>'code');
 end if;
 select * into v_t from kaz_tournaments where id=v_id for update;
 if not found then raise exception 'ARENA:not_found'; end if;
 if p_action='get' then return kaz_tournament_detail(v_id); end if;
 if p_action in ('start','cancel') and v_t.owner_id<>p_actor then raise exception 'ARENA:owner_only'; end if;
 if p_action='cancel' then
   if v_t.status not in ('registration','running') then raise exception 'ARENA:closed'; end if;
   update kaz_tournaments set status='cancelled',finished_at=now() where id=v_id;
 elsif p_action in ('join','leave') then
   if v_t.status<>'registration' then raise exception 'ARENA:closed'; end if;
   if p_action='leave' then
     if v_t.owner_id=p_actor then raise exception 'ARENA:owner_leave'; end if;
     delete from kaz_tournament_entries where tournament_id=v_id and user_id=p_actor;
   elsif not exists(select 1 from kaz_tournament_entries where tournament_id=v_id and user_id=p_actor) then
     if (select count(*) from kaz_tournament_entries where tournament_id=v_id)>=v_t.capacity then raise exception 'ARENA:full'; end if;
     insert into kaz_tournament_entries(tournament_id,user_id,name) values(v_id,p_actor,coalesce(nullif(left(trim(p_payload->>'playerName'),24),''),'Ойыншы'));
   end if;
 elsif p_action='start' then
   if v_t.status<>'registration' then raise exception 'ARENA:closed'; end if;
   select array_agg(user_id order by random()) into v_users from kaz_tournament_entries where tournament_id=v_id;
   if cardinality(v_users)<>v_t.capacity then raise exception 'ARENA:not_full'; end if;
   for v_n in 1..v_t.capacity loop
     update kaz_tournament_entries set seed=v_n where tournament_id=v_id and user_id=v_users[v_n];
   end loop;
   v_round:=1;v_size:=v_t.capacity/2;
   while v_size>=1 loop
     for v_slot in 1..v_size loop
       insert into kaz_tournament_matches(tournament_id,round,slot,player1,player2,status)
       values(v_id,v_round,v_slot,case when v_round=1 then v_users[v_slot*2-1] end,case when v_round=1 then v_users[v_slot*2] end,case when v_round=1 then 'ready' else 'pending' end);
     end loop;
     v_round:=v_round+1;v_size:=v_size/2;
   end loop;
   update kaz_tournaments set status='running',started_at=now() where id=v_id;
 elsif p_action in ('match','bind','result') then
   select * into v_m from kaz_tournament_matches where id=(p_payload->>'match')::uuid;
   if p_actor is distinct from v_m.player1 and p_actor is distinct from v_m.player2 then raise exception 'ARENA:match_only'; end if;
   if p_action='result' and (v_m.status<>'playing' or v_m.room_code is distinct from p_payload->>'room' or v_t.status<>'running') then return kaz_tournament_detail(v_id); end if;
   if v_t.status<>'running' or v_m.status not in ('ready','playing') then raise exception 'ARENA:closed'; end if;
   if p_action='match' then return jsonb_build_object('match',to_jsonb(v_m),'tournament',to_jsonb(v_t)); end if;
   if p_action='bind' then
     v_code:=p_payload->>'room';
     if v_code !~ '^[A-Z0-9]{4,12}$' then raise exception 'ARENA:invalid'; end if;
     update kaz_tournament_matches set room_code=v_code,status='playing',attempts=attempts+1 where id=v_m.id;
   else
     v_win:=nullif(p_payload->>'winner','')::uuid;
     if v_win is null then
       -- A draw creates a replay of the same pairing, with no advancement.
       update kaz_tournament_matches set status='ready',room_code=null where id=v_m.id;
     else
       if v_win is distinct from v_m.player1 and v_win is distinct from v_m.player2 then raise exception 'ARENA:invalid'; end if;
       update kaz_tournament_matches set status='finished',winner_id=v_win where id=v_m.id;
       select * into v_next from kaz_tournament_matches where tournament_id=v_id and round=v_m.round+1 and slot=(v_m.slot+1)/2;
       if not found then
         update kaz_tournaments set status='completed',winner_id=v_win,finished_at=now() where id=v_id;
       else
         update kaz_tournament_matches set player1=case when v_m.slot%2=1 then v_win else player1 end,player2=case when v_m.slot%2=0 then v_win else player2 end where id=v_next.id;
         update kaz_tournament_matches set status='ready' where id=v_next.id and player1 is not null and player2 is not null;
       end if;
     end if;
   end if;
 else raise exception 'ARENA:invalid';
 end if;
 return kaz_tournament_detail(v_id);
end $$;
revoke all on function public.kaz_tournament(uuid,text,jsonb) from public,anon,authenticated;
grant execute on function public.kaz_tournament(uuid,text,jsonb) to service_role;
notify pgrst, 'reload schema';
commit;
