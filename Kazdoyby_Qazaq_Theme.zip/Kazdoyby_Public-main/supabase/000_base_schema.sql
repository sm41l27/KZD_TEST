-- Fresh Supabase project only. Then apply 001, 002, 003 and 004 in order.
-- No users, sample passwords or demo data are created here.
begin;
do $$
begin
  if to_regclass('auth.users') is null then
    raise exception 'KAZ_BASE: Run this file in a Supabase project with Auth enabled.';
  end if;
  if exists (
    select 1 from pg_tables where schemaname='public'
      and tablename in ('players','matches','match_players','moves')
  ) and coalesce(obj_description(to_regclass('public.players'),'pg_class'),'') <> 'kazdoyby.base.v1' then
    raise exception 'KAZ_BASE: Existing game tables detected. Skip 000 for an existing installation; do not delete your tables.';
  end if;
end $$;

create table if not exists public.players (
  id bigint generated always as identity primary key,
  auth_user_id uuid not null unique references auth.users(id) on delete cascade,
  client_id text,
  email text not null default '',
  name text not null,
  rating integer not null default 1000 check (rating>=0),
  games integer not null default 0 check (games>=0),
  wins integer not null default 0 check (wins>=0),
  losses integer not null default 0 check (losses>=0),
  draws integer not null default 0 check (draws>=0),
  created_at timestamptz not null default now()
);
comment on table public.players is 'kazdoyby.base.v1';
create index if not exists players_client_id_idx on public.players(client_id);

create table if not exists public.matches (
  id bigint generated always as identity primary key,
  room_code text not null,
  game_mode text not null check (game_mode in ('ffa','teams')),
  winner text,
  status text not null default 'playing' check (status in ('playing','finished','abandoned')),
  started_at timestamptz not null default now(),
  finished_at timestamptz
);
create table if not exists public.match_players (
  id bigint generated always as identity primary key,
  match_id bigint not null references public.matches(id) on delete cascade,
  player_id bigint references public.players(id) on delete set null,
  player_name text not null,
  color text not null check (color in ('blue','black','red','white')),
  player_type text not null check (player_type in ('human','ai')),
  bot_level text check (bot_level in ('easy','medium','hard')),
  result text check (result in ('win','loss','draw')),
  unique (match_id,color)
);
create index if not exists match_players_player_history_idx on public.match_players(player_id,id desc);
create table if not exists public.moves (
  id bigint generated always as identity primary key,
  match_id bigint not null references public.matches(id) on delete cascade,
  move_number integer not null check (move_number>0),
  player_color text not null check (player_color in ('blue','black','red','white')),
  from_square text not null,
  to_square text not null,
  captures jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique (match_id,move_number)
);

-- All game data goes through the existing authenticated Node.js server.
alter table public.players enable row level security;
alter table public.matches enable row level security;
alter table public.match_players enable row level security;
alter table public.moves enable row level security;
revoke all on public.players,public.matches,public.match_players,public.moves from public,anon,authenticated;
grant usage on schema public to service_role;
grant select,insert,update,delete on public.players,public.matches,public.match_players,public.moves to service_role;
revoke all on sequence public.players_id_seq,public.matches_id_seq,public.match_players_id_seq,public.moves_id_seq from public,anon,authenticated;
grant usage,select on sequence public.players_id_seq,public.matches_id_seq,public.match_players_id_seq,public.moves_id_seq to service_role;
notify pgrst,'reload schema';
commit;
