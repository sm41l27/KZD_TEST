-- Apply after 001_social.sql and 002_arena.sql. Safe to reapply.
begin;
alter table public.kaz_social_profiles add column if not exists avatar jsonb not null default '{"type":"icon","value":"pawn"}'::jsonb;
alter table public.kaz_tournament_matches add column if not exists seats jsonb;
alter table public.kaz_tournament_matches add column if not exists game_started_at timestamptz;

create or replace function public.kaz_set_avatar(p_actor uuid,p_avatar jsonb,p_name text default 'Ойыншы') returns jsonb
language plpgsql security invoker set search_path=public,pg_temp as $$
begin
 if p_actor is null then raise exception 'ROOM:auth_required'; end if;
 if jsonb_typeof(p_avatar) is distinct from 'object' or octet_length(p_avatar::text)>70000 then raise exception 'ROOM:invalid_avatar'; end if;
 if not coalesce(
   (p_avatar->>'type'='icon' and p_avatar->>'value' in('pawn','crown','knight','star','shield','bolt','leaf','compass','moon','sun','gem','rook')) or
   (p_avatar->>'type'='photo' and (p_avatar->>'value') ~ '^data:image/jpeg;base64,[A-Za-z0-9+/]+={0,2}$'),false)
 then raise exception 'ROOM:invalid_avatar';end if;
 insert into kaz_social_profiles(id,name,avatar) values(p_actor,left(coalesce(nullif(trim(p_name),''),'Ойыншы'),24),jsonb_build_object('type',p_avatar->>'type','value',p_avatar->>'value'))
 on conflict(id) do update set avatar=excluded.avatar,updated_at=now();
 return (select to_jsonb(p) from kaz_social_profiles p where id=p_actor);
end $$;
revoke all on function public.kaz_set_avatar(uuid,jsonb,text) from public,anon,authenticated;
grant execute on function public.kaz_set_avatar(uuid,jsonb,text) to service_role;

-- Server-only match-room operations. Bracket registration and result RPC stay unchanged.
create or replace function public.kaz_tournament_room(p_actor uuid,p_match uuid,p_action text,p_payload jsonb default '{}'::jsonb) returns jsonb
language plpgsql security invoker set search_path=public,pg_temp as $$
declare v_m kaz_tournament_matches;v_t kaz_tournaments;v_id uuid;v_seats jsonb;v_key text;v_value text;v_count integer;v_left integer;v_right integer;
begin
 select tournament_id into v_id from kaz_tournament_matches where id=p_match;
 select * into v_t from kaz_tournaments where id=v_id for update;
 select * into v_m from kaz_tournament_matches where id=p_match;
 if v_t.id is null or v_m.id is null then raise exception 'ROOM:not_found';end if;
 if p_actor is null then raise exception 'ROOM:auth_required';end if;
 if p_actor<>v_t.owner_id and p_actor is distinct from v_m.player1 and p_actor is distinct from v_m.player2 then raise exception 'ROOM:pair_only';end if;
 if v_t.status<>'running' or v_m.status not in('ready','playing') then raise exception 'ROOM:closed';end if;
 if p_action='inspect' then
   return jsonb_build_object('match',to_jsonb(v_m),'tournament',to_jsonb(v_t));
 elsif p_action='bind' then
   if not coalesce((p_payload->>'room') ~ '^[A-Z0-9]{4,12}$',false) then raise exception 'ROOM:invalid';end if;
   update kaz_tournament_matches set room_code=p_payload->>'room',status='playing',attempts=attempts+1,game_started_at=null,
     seats=coalesce(seats,jsonb_build_object('blue',player1::text,'red',player2::text)) where id=p_match returning * into v_m;
 elsif p_action='unlock' then
   if p_actor<>v_t.owner_id or v_m.room_code is distinct from p_payload->>'room' then raise exception 'ROOM:owner_only';end if;
   update kaz_tournament_matches set game_started_at=null where id=p_match returning * into v_m;
 elsif p_action in('seats','start') then
   if p_actor<>v_t.owner_id then raise exception 'ROOM:owner_only';end if;
   if v_m.room_code is distinct from p_payload->>'room' then raise exception 'ROOM:closed';end if;
   if v_m.game_started_at is not null then raise exception 'ROOM:started';end if;
   v_seats:=p_payload->'seats';
   if jsonb_typeof(v_seats) is distinct from 'object' then raise exception 'ROOM:invalid';end if;
   v_count:=0;v_left:=0;v_right:=0;
   for v_key,v_value in select * from jsonb_each_text(v_seats) loop
     if v_key not in('blue','black','red','white') or v_value is null or v_value not in(v_m.player1::text,v_m.player2::text) then raise exception 'ROOM:pair_only';end if;
     v_count:=v_count+1;
     if v_key in('blue','black') then v_left:=v_left+1;else v_right:=v_right+1;end if;
   end loop;
   if v_count>2 or v_count<>(select count(distinct value) from jsonb_each_text(v_seats)) then raise exception 'ROOM:invalid';end if;
   if p_action='start' and (v_count<>2 or v_left<>1 or v_right<>1) then raise exception 'ROOM:opposite_teams';end if;
   update kaz_tournament_matches set seats=v_seats,game_started_at=case when p_action='start' then now() else null end where id=p_match returning * into v_m;
 else raise exception 'ROOM:invalid';end if;
 return jsonb_build_object('match',to_jsonb(v_m),'tournament',to_jsonb(v_t));
end $$;
revoke all on function public.kaz_tournament_room(uuid,uuid,text,jsonb) from public,anon,authenticated;
grant execute on function public.kaz_tournament_room(uuid,uuid,text,jsonb) to service_role;
notify pgrst,'reload schema';
commit;
