const {test}=require('node:test'),assert=require('node:assert/strict');
const {fixture,A,B,C,D}=require('./arena-fixture.cjs');
const {io:connect}=require('socket.io-client');
const once=(s,event)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Timed out '+event)),5000);s.once(event,data=>{clearTimeout(timer);resolve(data);});});
const request=(s,event,payload)=>new Promise(r=>s.emit(event,payload,r));
const tour=(s,action,payload={})=>request(s,'tournament:request',{action,payload});
const control=(s,action,target,seat)=>request(s,'room:command',{action,target,seat});
const leave=s=>request(s,'leave-room',{});
const until=async fn=>{for(let i=0;i<150;i++){if(await fn())return;await new Promise(r=>setTimeout(r,20));}throw Error('Condition not met');};
test('Organizer seating, private commands and persistent avatars',async t=>{
 const f=await fixture();t.after(()=>f.close());
 const sockets=new Map();for(const id of [A,B,C,D]){const s=connect(f.url,{auth:{token:id}});await once(s,'connect');sockets.set(id,s);}
 const a=sockets.get(A),b=sockets.get(B),guest=connect(f.url);await once(guest,'connect');t.after(()=>{for(const s of sockets.values())s.disconnect();guest.disconnect();});
 await t.test('new RPCs are inaccessible to browser database roles',async()=>{
  for(const role of ['anon','authenticated']){
   await assert.rejects(f.db.transaction(async tx=>{await tx.exec('set local role '+role);await tx.query("select kaz_set_avatar($1,'{}'::jsonb,'Name')",[A]);}),/permission denied/);
   await assert.rejects(f.db.transaction(async tx=>{await tx.exec('set local role '+role);await tx.query("select kaz_tournament_room($1,$2,'inspect','{}')",[A,B]);}),/permission denied/);
  }
 });
 await t.test('avatar save derives owner from token and rejects executable or oversized content',async()=>{
  assert.equal((await request(guest,'avatar:save',{avatar:{type:'icon',value:'crown'},actor:A})).ok,false);
  const out=await request(a,'avatar:save',{avatar:{type:'icon',value:'crown'},actor:B});assert.equal(out.ok,true);
  const rows=(await f.db.query('select id,avatar from kaz_social_profiles')).rows;assert.deepEqual(rows.map(x=>[x.id,x.avatar.value]),[[A,'crown']]);
  const validate=require('../avatars-server').validate;
  assert.equal(validate({type:'photo',value:'data:image/svg+xml,<svg onload=alert(1)>'}),false);
  assert.equal(validate({type:'photo',value:'https://host.test/x.jpg'}),false);
  assert.equal(validate({type:'icon',value:'<script>'}),false);
  assert.equal(validate({type:'photo',value:'data:image/jpeg;base64,'+'A'.repeat(100000)}),false);
 });
 await t.test('regular host can swap colors, demote a player, promote a logged-in spectator, and start manually',async()=>{
  let joined=once(a,'room-created');a.emit('create-room',{code:'SEATS1',ratingMode:'friendly',gameMode:'teams',playerTypes:{blue:'human',black:'ai-medium',red:'human',white:'ai-medium'}});await joined;
  joined=once(b,'room-joined');b.emit('join-room',{code:'SEATS1'});await joined;const room=f.rooms.get('SEATS1');assert.equal(room.started,false);
  assert.equal((await control(b,'move',a.id,'spectator')).error,'owner_only');
  assert.equal((await control(a,'move',b.id,'white')).ok,true);assert.equal(room.slots.white,b.id);assert.equal(room.playerTypes.red,'ai-medium');
  assert.equal((await control(a,'move',a.id,'white')).ok,true);assert.equal(room.slots.blue,b.id);assert.equal(room.slots.white,a.id);
  assert.equal((await control(a,'move',b.id,'spectator')).ok,true);assert.equal(room.spectators.has(b.id),true);
  assert.equal((await control(a,'start')).error,'missing_players');
  assert.equal((await control(a,'move',b.id,'black')).ok,true);assert.equal(room.slots.black,b.id);
  joined=once(guest,'room-spectating');guest.emit('watch-room',{code:'SEATS1'});await joined;
  assert.equal((await control(a,'move',guest.id,'blue')).error,'login_to_play');
  assert.equal((await control(a,'start')).ok,true);assert.equal(room.started,true);
  assert.equal((await control(a,'move',b.id,'spectator')).error,'started');
  await leave(b);
  const outsider=sockets.get(C),blocked=once(outsider,'room-error');outsider.emit('join-room',{code:'SEATS1'});
  assert.equal(await blocked,'room.error.started');assert.equal(room.slots.black,null);
  joined=once(b,'room-joined');b.emit('join-room',{code:'SEATS1'});assert.equal((await joined).color,'black');
  for(const s of [a,b,guest])await leave(s);
 });
 await t.test('tournament owner controls another pairing as a spectator; black/white winners advance correctly',async()=>{
  let d=(await tour(a,'create',{name:'Organizer cup',capacity:4,time:180})).data;
  for(const id of [B,C,D])await tour(sockets.get(id),'join',{id:d.id});d=(await tour(a,'start',{id:d.id})).data;
  const match=d.matches.find(m=>m.round===1&&m.player1!==A&&m.player2!==A),p=sockets.get(match.player1),q=sockets.get(match.player2);
  const opened=await tour(a,'manage',{match:match.id});assert.equal(opened.ok,true);assert.equal(opened.data.watch,true);const code=opened.data.code;
  let joined=once(a,'room-spectating');a.emit('watch-room',{code});await joined;const room=f.rooms.get(code);
  joined=once(p,'room-joined');p.emit('join-room',{code});await joined;
  assert.equal((await control(a,'move',p.id,'black')).ok,true);
  assert.equal(room.tournament.players.red,match.player2,'Unconnected reserved opponent must retain their seat');
  joined=once(q,'room-joined');q.emit('join-room',{code});await joined;
  assert.equal((await control(a,'move',q.id,'white')).ok,true);
  assert.equal((await control(p,'start')).error,'owner_only');
  assert.equal((await control(a,'move',a.id,'blue')).error,'pair_only');
  assert.equal((await control(a,'move',q.id,'blue')).ok,true);
  assert.equal((await control(a,'start')).error,'opposite_teams');
  assert.equal((await control(a,'move',q.id,'spectator')).ok,true);assert.equal((await control(a,'start')).error,'opposite_teams');
  assert.equal((await control(a,'move',q.id,'white')).ok,true);
  const stored=(await f.db.query('select seats from kaz_tournament_matches where id=$1',[match.id])).rows[0].seats;
  assert.deepEqual(stored,{black:match.player1,white:match.player2});
  assert.equal((await control(a,'start')).ok,true);assert.equal(room.started,true);assert.equal(room.spectators.has(a.id),true);
  assert.equal((await control(a,'move',p.id,'spectator')).error,'started');
  const denied=once(a,'room-error');a.emit('game-state',{state:JSON.stringify({board:[],currentPlayer:'black',gameMode:'teams'}),winner:'blue-black'});await denied;assert.equal(room.winner,null);
  q.emit('resign-room');await until(async()=>{d=await f.rpc(A,'get',{id:d.id});return d.matches.find(m=>m.id===match.id).status==='finished';});
  assert.equal(d.matches.find(m=>m.id===match.id).winner_id,match.player1);
  await room.dbQueue;
  for(const s of [a,p,q])await leave(s);
 });
});
