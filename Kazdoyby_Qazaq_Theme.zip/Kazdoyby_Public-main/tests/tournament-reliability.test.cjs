const {test}=require('node:test'),assert=require('node:assert/strict');
const {fixture,A,B,C}=require('./arena-fixture.cjs');
const {io}=require('socket.io-client'),engine=require('../game-engine');
const once=(socket,event)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Timeout '+event)),8000);socket.once(event,data=>{clearTimeout(timer);resolve(data);});});
const call=(socket,event,payload)=>new Promise(r=>socket.emit(event,payload,r));
const tour=(s,action,payload={})=>call(s,'tournament:request',{action,payload});
const until=async fn=>{const end=Date.now()+10000;while(Date.now()<end){if(await fn())return;await new Promise(r=>setTimeout(r,20));}throw Error('State did not advance');};
test('Tournament server owns moves, bot work, recovery, difficulty and history',async t=>{
 const f=await fixture(),sockets=[];t.after(async()=>{sockets.forEach(s=>s.disconnect());await f.close();});
 async function client(id){const s=io(f.url,{auth:{token:id}});sockets.push(s);await once(s,'connect');return s;}
 const a=await client(A),b=await client(B),viewer=await client(C);
 await t.test('difficulty is persisted, owner-only and immutable after registration; history removal is scoped',async()=>{
  let d=(await tour(a,'create',{name:'Difficulty cup',capacity:2,time:180,aiLevel:'easy'})).data;
  assert.equal(d.ai_level,'easy');assert.equal((await tour(b,'configure',{id:d.id,aiLevel:'hard'})).error,'owner_only');
  d=(await tour(a,'configure',{id:d.id,aiLevel:'hard'})).data;assert.equal(d.ai_level,'hard');
  await tour(b,'join',{id:d.id});d=(await tour(a,'start',{id:d.id})).data;
  assert.equal((await tour(a,'configure',{id:d.id,aiLevel:'easy'})).error,'closed');assert.equal((await tour(a,'delete',{id:d.id})).error,'history_active');
  await tour(a,'cancel',{id:d.id});assert.equal((await tour(b,'delete',{id:d.id})).error,'owner_only');
  assert.equal((await tour(b,'hide',{id:d.id})).ok,true);assert.ok(!(await tour(b,'list')).data.some(x=>x.id===d.id));assert.ok((await tour(a,'list')).data.some(x=>x.id===d.id));
  assert.equal((await tour(a,'delete',{id:d.id})).ok,true);assert.equal((await tour(a,'get',{id:d.id})).error,'not_found');
  for(const role of ['anon','authenticated'])await assert.rejects(f.db.transaction(async tx=>{await tx.exec('set local role '+role);await tx.query('select * from kaz_tournament_hidden');}),/permission denied/);
 });
 await t.test('full human/bot cycles continue without a host browser, with stale/forged moves rejected and reconnection synchronized',async()=>{
  let d=(await tour(a,'create',{name:'Reliable cup',capacity:2,time:180,aiLevel:'hard'})).data;
  await tour(b,'join',{id:d.id});d=(await tour(a,'start',{id:d.id})).data;const m=d.matches[0];
  const code=(await tour(a,'enter',{match:m.id})).data.code;
  for(const s of [a,b]){const joined=once(s,'room-joined');s.emit('join-room',{code});await joined;}
  let joined=once(viewer,'room-spectating');viewer.emit('watch-room',{code});await joined;
  assert.equal((await call(a,'room:command',{action:'start'})).ok,true);
  const room=f.rooms.get(code);assert.equal(room.playerTypes.black,'ai-hard');assert.equal(room.playerTypes.white,'ai-hard');
  let blue=m.player1===A?a:b,red=m.player2===A?a:b;
  const first=engine.legal(room.engineState)[0];
  assert.equal((await call(viewer,'tournament:move',{...first,revision:0})).error,'not_your_turn');
  assert.equal((await call(blue,'tournament:move',{from:first.from,to:first.to,revision:-1})).error,'stale');
  const original=room.state,denied=once(blue,'room-error');blue.emit('game-state',{state:original,winner:'blue-black'});assert.equal(await denied,'play.serverTurns');assert.equal(room.winner,null);
  const duplicate={from:first.from,to:first.to,revision:0};
  const results=await Promise.all([call(blue,'tournament:move',duplicate),call(blue,'tournament:move',duplicate)]);assert.equal(results.filter(r=>r.ok).length,1);
  await until(()=>room.expectedPlayer==='red');assert.equal(room.engineState.historyLog.length,2);
  // Remove the former browser AI controller. White still moves on the server.
  blue.disconnect();await until(()=>!room.slots.blue);
  const redMove=engine.legal(room.engineState)[0];assert.equal((await call(red,'tournament:move',{from:redMove.from,to:redMove.to,revision:room.revision})).ok,true);
  await until(()=>room.expectedPlayer==='blue');assert.equal(room.engineState.historyLog.length,4);
  blue=await client(m.player1);const snapshot=once(blue,'game-state');joined=once(blue,'room-joined');blue.emit('join-room',{code});await joined;const restored=await snapshot;
  assert.equal(restored.revision,room.revision);assert.equal(JSON.parse(restored.state).currentPlayer,'blue');
  for(let turn=0;turn<4&&!room.winner;turn++){
   const s=room.expectedPlayer==='blue'?blue:red;const move=engine.legal(room.engineState)[0],count=room.engineState.historyLog.length;
   assert.equal((await call(s,'tournament:move',{from:move.from,to:move.to,revision:room.revision})).ok,true);
   await until(()=>room.winner||room.playerTypes[room.expectedPlayer]==='human');assert.ok(room.engineState.historyLog.length>=count+2);
   const sync=await call(viewer,'tournament:sync',{});assert.equal(sync.state,room.state);assert.equal(sync.revision,room.revision);
  }
  assert.equal(room.engineError,undefined);
  red.emit('resign-room');await until(async()=>{d=await f.rpc(A,'get',{id:d.id});return d.status==='completed';});assert.equal(d.winner_id,m.player1);
  await room.dbQueue;assert.equal((await f.db.query('select rating from players where auth_user_id=$1',[m.player1])).rows[0].rating,1000);
  for(const s of [blue,red,viewer])await call(s,'leave-room',{});
 });
});
