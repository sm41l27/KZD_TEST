const {test}=require('node:test');
const assert=require('node:assert/strict');
const {fixture,A,B,C,D}=require('./arena-fixture.cjs');
const {io:connect}=require('socket.io-client');
const once=(s,event)=>new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error('Timed out: '+event)),5000);s.once(event,data=>{clearTimeout(timeout);resolve(data);});});
const call=(s,action,payload={})=>new Promise(r=>s.emit('tournament:request',{action,payload},r));
const command=(s,payload)=>new Promise(r=>s.emit('room:command',payload,r));
const until=async fn=>{for(let i=0;i<150;i++){if(await fn())return;await new Promise(r=>setTimeout(r,20));}throw Error('Condition not met');};
test('Tournament persistence, rating modes and actual room spectator permissions',async t=>{
 const f=await fixture();t.after(()=>f.close());const {rpc,db}=f;
 await t.test('new tables and RPC cannot be accessed with public client credentials',async()=>{
  for(const role of ['anon','authenticated'])await assert.rejects(db.transaction(async tx=>{await tx.exec('set local role '+role);await tx.query('select kaz_tournament($1,$2,$3::jsonb)',[A,'list','{}']);}),/permission denied/);
 });
 await t.test('capacity, organizer checks, draws and automatic knockout advancement are enforced in SQL',async()=>{
  let tour=await rpc(A,'create',{name:'Four players',capacity:4,time:180,playerName:'Alice'});
  await assert.rejects(rpc(A,'start',{id:tour.id}),/ARENA:not_full/);
  await assert.rejects(rpc(B,'cancel',{id:tour.id}),/ARENA:owner_only/);
  for(const id of [B,C,D])tour=await rpc(id,'join',{id:tour.id,playerName:id});
  assert.equal(tour.entries.length,4);await rpc(B,'join',{id:tour.id});
  tour=await rpc(A,'start',{id:tour.id});assert.equal(tour.matches.length,3);
  let m=tour.matches[0];await rpc(m.player1,'bind',{match:m.id,room:'DRAW11'});
  tour=await rpc(m.player1,'result',{match:m.id,room:'DRAW11',winner:null});assert.equal(tour.matches[0].status,'ready');
  assert.equal(tour.matches.find(x=>x.round===2).player1,null);
  await rpc(m.player1,'bind',{match:m.id,room:'REPLAY'});
  tour=await rpc(m.player1,'result',{match:m.id,room:'DRAW11',winner:m.player2});assert.equal(tour.matches[0].status,'playing');
  tour=await rpc(m.player1,'result',{match:m.id,room:'REPLAY',winner:m.player1});
  const firstWinner=m.player1;
  tour=await rpc(m.player1,'result',{match:m.id,room:'REPLAY',winner:m.player2});assert.equal(tour.matches[0].winner_id,firstWinner);
  m=tour.matches.find(x=>x.round===1&&x.slot===2);await rpc(m.player1,'bind',{match:m.id,room:'SEMI22'});
  tour=await rpc(m.player1,'result',{match:m.id,room:'SEMI22',winner:m.player2});
  m=tour.matches.find(x=>x.round===2);assert.equal(m.status,'ready');assert.equal(m.player1,firstWinner);
  await rpc(m.player1,'bind',{match:m.id,room:'FINAL1'});
  tour=await rpc(m.player1,'result',{match:m.id,room:'FINAL1',winner:m.player2});assert.equal(tour.status,'completed');assert.equal(tour.winner_id,m.player2);
  await assert.rejects(rpc(A,'cancel',{id:tour.id}),/ARENA:closed/);
 });
 await t.test('friendly and tournament games keep ELO exactly; rated games retain the original rating changes',async()=>{
  const rows=(await db.query('select * from players order by id')).rows;
  for(const mode of ['friendly','tournament','rated']){
   const room=f.createRoomRecord({code:'ELO123',ratingMode:mode,playerTypes:{blue:'human',red:'human',black:'ai-medium',white:'ai-medium'}});room.profiles.blue=rows[0];room.profiles.red=rows[1];
   await f.updatePlayerStatistics(room,new Set(['blue','black']));
   const a=(await db.query('select rating from players where auth_user_id=$1',[A])).rows[0].rating;
   assert.equal(a,mode==='rated'?1020:1000);
  }
 });
 const a=connect(f.url,{auth:{token:A}}),b=connect(f.url,{auth:{token:B}}),c=connect(f.url,{auth:{token:C}}),viewer=connect(f.url);
 await Promise.all([a,b,c,viewer].map(s=>once(s,'connect')));
 t.after(()=>{for(const s of [a,b,c,viewer])s.disconnect();});
 const leave=s=>new Promise(r=>s.emit('leave-room',{},r));
 await t.test('spectators receive snapshots, occupy no seats, cannot move/restart/rename, and retain a room until its last member leaves',async()=>{
  let joined=once(a,'room-created');a.emit('create-room',{code:'FRIEND',ratingMode:'friendly',gameMode:'teams',playerTypes:{blue:'human',black:'ai-medium',red:'human',white:'ai-medium'}});await joined;
  joined=once(b,'room-joined');b.emit('join-room',{code:'FRIEND'});await joined;
  const room=f.rooms.get('FRIEND');assert.equal(room.ratingMode,'friendly');assert.equal(room.started,false);assert.equal((await command(a,{action:'start'})).ok,true);
  const state=JSON.stringify({board:[[null]],gameMode:'teams',currentPlayer:'blue'});a.emit('game-state',{state});await until(()=>room.state===state);
  const snapshot=once(viewer,'game-state');joined=once(viewer,'room-spectating');viewer.emit('watch-room',{code:'FRIEND'});const watched=await joined;await snapshot;
  assert.equal(watched.status.connected,2);assert.equal(room.spectators.size,1);assert.equal(watched.color,null);
  const denied=once(viewer,'room-error');viewer.emit('game-state',{state,winner:'red-white'});await denied;assert.equal(room.winner,null);
  viewer.emit('restart-room');viewer.emit('change-room-code',{code:'BAD123'});await new Promise(r=>setTimeout(r,30));assert.equal(room.state,state);assert.equal(room.code,'FRIEND');
  await leave(viewer);assert.equal(room.spectators.size,0);assert.equal(f.roomStatus(room).connected,2);
  joined=once(viewer,'room-spectating');viewer.emit('watch-room',{code:'FRIEND'});await joined;
  await leave(a);await leave(b);assert.equal(f.rooms.has('FRIEND'),true);await leave(viewer);assert.equal(f.rooms.has('FRIEND'),false);
 });
 await t.test('spectators can be disabled by the creator',async()=>{
  const joined=once(a,'room-created');a.emit('create-room',{code:'HIDDEN',allowSpectators:false,playerTypes:{blue:'human',black:'human',red:'human',white:'human'}});await joined;
  const denied=once(viewer,'room-error');viewer.emit('watch-room',{code:'HIDDEN'});assert.equal(await denied,'arena.error.watch_disabled');await leave(a);
 });
 await t.test('real tournament rooms enforce pair assignment, client result prohibition, no restart and persisted resignation result',async()=>{
  assert.equal((await call(viewer,'list')).error,'auth_required');assert.equal((await call(a,'result',{})).error,'invalid');
  let out=await call(a,'create',{name:'Live tournament',capacity:2,time:180});assert.equal(out.ok,true);let tour=out.data;
  await call(b,'join',{id:tour.id});tour=(await call(a,'start',{id:tour.id})).data;const m=tour.matches[0];
  const [ea,eb]=await Promise.all([call(a,'enter',{match:m.id}),call(b,'enter',{match:m.id})]);assert.equal(ea.data.code,eb.data.code);const code=ea.data.code;
  const denied=once(c,'room-error');c.emit('join-room',{code});assert.equal(await denied,'arena.error.match_only');
  let joined=once(a,'room-joined');a.emit('join-room',{code});const aa=await joined;assert.equal(aa.color,m.player1===A?'blue':'red');
  joined=once(b,'room-joined');b.emit('join-room',{code});await joined;
  const room=f.rooms.get(code);assert.equal(room.ratingMode,'tournament');assert.equal(room.started,false);assert.equal((await command(a,{action:'start'})).ok,true);assert.equal(room.started,true);
  const host=a;const locked=once(host,'room-error');host.emit('restart-room');assert.equal(await locked,'arena.error.tournament_locked');
  const saved=(await db.query('select rating from players where auth_user_id=$1',[B])).rows[0].rating;
  a.emit('resign-room');await until(async()=>{tour=await rpc(A,'get',{id:tour.id});return tour.status==='completed';});assert.equal(tour.winner_id,B);
  await until(()=>room.dbFinished);await room.dbQueue;
  assert.equal((await db.query('select rating from players where auth_user_id=$1',[B])).rows[0].rating,saved);
  assert.equal((await db.query('select rating_mode from matches where room_code=$1',[code])).rows[0].rating_mode,'tournament');
  await leave(a);await leave(b);
 });
});
