const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {PGlite}=require('@electric-sql/pglite');
const {randomUUID}=require('node:crypto');
const path=require('node:path');
const A='11111111-1111-4111-8111-111111111111',B='22222222-2222-4222-8222-222222222222',C='33333333-3333-4333-8333-333333333333';
async function database(){
 const db=new PGlite();
 await db.exec(`create role anon;create role authenticated;create role service_role bypassrls;create schema auth;create table auth.users(id uuid primary key);create table public.players(id bigint generated always as identity primary key,auth_user_id uuid unique,name text);create table public.matches(id bigint primary key,game_mode text,started_at timestamptz);create table public.match_players(id bigint generated always as identity primary key,match_id bigint,player_id bigint,color text,player_type text);grant select on public.players,public.matches,public.match_players to service_role;insert into auth.users values('${A}'),('${B}'),('${C}');insert into players(auth_user_id,name)values('${A}','Alice'),('${B}','Bob'),('${C}','Carol');`);
 const sql=fs.readFileSync(path.join(__dirname,'../supabase/001_social.sql'),'utf8');
 await db.exec(sql);await db.exec(sql); // Reapplying the migration must preserve data/schema.
 const rpc=(actor,action,payload={})=>db.transaction(async tx=>{await tx.exec('set local role service_role');return(await tx.query('select public.kaz_social($1,$2,$3::jsonb) data',[actor,action,JSON.stringify(payload)])).rows[0].data;});
 return {db,rpc};
}
module.exports={database,A,B,C};
if(require.main===module)test('Persistent friends, private chat and invitations',async t=>{
 const {db,rpc}=await database();t.after(()=>db.close());
 await rpc(A,'init',{name:'Alice'});await rpc(B,'init',{name:'Bob'});await rpc(C,'init',{name:'Carol'});
 await t.test('client roles cannot read private tables or impersonate an actor through RPC',async()=>{
  for(const role of ['anon','authenticated']){
   await assert.rejects(db.transaction(async tx=>{await tx.exec(`set local role ${role}`);await tx.query('select * from public.kaz_messages');}),/permission denied/);
   await assert.rejects(db.transaction(async tx=>{await tx.exec(`set local role ${role}`);await tx.query('select public.kaz_social($1,$2,$3::jsonb)',[A,'dashboard','{}']);}),/permission denied/);
  }
 });
 await t.test('names/codes resolve without exposing emails; requester cannot accept own request',async()=>{
  const found=await rpc(A,'search',{query:'Bob'});assert.equal(found[0].id,B);assert.equal(found[0].email,undefined);
  await rpc(A,'request',{target:B});await rpc(A,'request',{target:B});
  assert.equal((await rpc(B,'dashboard')).friends.length,1);
  await assert.rejects(rpc(A,'accept',{target:B}),/SOCIAL:invalid/);
  await assert.rejects(rpc(A,'send',{target:B,body:'Hi',nonce:randomUUID()}),/SOCIAL:not_friends/);
  await rpc(B,'accept',{target:A});
 });
 await t.test('chat persists, retries are idempotent, strangers cannot read, cursors do not mark unseen messages',async()=>{
  const nonce=randomUUID();const first=await rpc(A,'send',{target:B,body:'Hello <script> & friends',nonce});
  await rpc(A,'send',{target:B,body:'Hello <script> & friends',nonce});
  assert.equal((await rpc(B,'messages',{target:A})).length,1);
  assert.equal(Number((await rpc(B,'dashboard')).friends[0].unread),1);
  await assert.rejects(rpc(C,'messages',{target:A}),/SOCIAL:not_friends/);
  const second=await rpc(A,'send',{target:B,body:'Second message',nonce:randomUUID()});
  await rpc(B,'read',{target:A,last:first.id});assert.equal(Number((await rpc(B,'dashboard')).friends[0].unread),1);
  const older=await rpc(B,'messages',{target:A,before:second.id});assert.equal(older.length,1);
 });
 await t.test('only invite recipient can consume live invitations; duplicates reuse a pending invite',async()=>{
  const inv=await rpc(A,'invite',{target:B,code:'ABC123'});const retry=await rpc(A,'invite',{target:B,code:'ABC123'});assert.equal(inv.id,retry.id);
  await assert.rejects(rpc(C,'invitation',{id:inv.id}),/SOCIAL:invite_expired/);
  assert.equal((await rpc(B,'invitation',{id:inv.id})).code,'ABC123');
  await rpc(B,'joined',{id:inv.id});await assert.rejects(rpc(B,'invitation',{id:inv.id}),/SOCIAL:invite_expired/);
  const expired=await rpc(A,'invite',{target:B,code:'ABC456'});await db.query("update kaz_game_invites set expires_at=now()-interval '1 second' where id=$1",[expired.id]);await assert.rejects(rpc(B,'invitation',{id:expired.id}),/SOCIAL:invite_expired/);
 });
 await t.test('recent opponents exclude bots and teammates',async()=>{
  await db.exec("insert into matches values(1,'teams',now());insert into match_players(match_id,player_id,color,player_type)values(1,1,'blue','human'),(1,2,'black','human'),(1,3,'red','human'),(1,null,'white','ai');");
  const recent=(await rpc(A,'dashboard')).recent;assert.equal(recent.length,1);assert.equal(recent[0].id,C);
 });
 await t.test('removing a friend revokes chat access and pending invitations',async()=>{
  await rpc(A,'invite',{target:B,code:'ABCD77'});await rpc(B,'remove',{target:A});
  await assert.rejects(rpc(A,'messages',{target:B}),/SOCIAL:not_friends/);
  await assert.rejects(rpc(A,'send',{target:B,body:'No',nonce:randomUUID()}),/SOCIAL:not_friends/);
  assert.equal((await rpc(B,'dashboard')).invites.length,0);
 });
 await t.test('server derives actor from token, checks live seats, and notifies only private user channels',async()=>{
  const http=require('node:http');const {Server}=require('socket.io');const {io:connect}=require('socket.io-client');
  const server=http.createServer();const io=new Server(server);const rooms=new Map();
  require('../social-server')({io,rooms,enabled:true,fetchAuthUser:async token=>token===A?{id:A}:token===B?{id:B}:null,supabaseRest:async(_table,{body})=>rpc(body.p_actor,body.p_action,body.p_payload)});
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  const a=connect(`http://127.0.0.1:${server.address().port}`,{auth:{token:A}}),b=connect(`http://127.0.0.1:${server.address().port}`,{auth:{token:B}}),stranger=connect(`http://127.0.0.1:${server.address().port}`,{auth:{token:'invalid'}});
  try{
   await Promise.all([a,b,stranger].map(s=>new Promise(r=>s.on('connect',r))));
   const call=(s,action,payload={})=>new Promise(r=>s.emit('social:request',{action,payload},r));
   assert.equal((await call(stranger,'dashboard',{actor:A})).error,'auth_required');
   await call(a,'init');await call(b,'init');
   await call(a,'request',{target:B,actor:C});assert.equal((await rpc(B,'dashboard')).friends[0].requester,A);
   await call(b,'accept',{target:A});
   assert.equal((await call(a,'invite',{target:B,code:'NOCODE'})).error,'room_unavailable');
   rooms.set('ABC123',{profiles:{blue:{auth_user_id:A}},slots:{blue:a.id,red:null},playerTypes:{blue:'human',red:'human'},winner:null});
   const inv=await call(a,'invite',{target:B,code:'ABC123'});assert.equal(inv.ok,true);
   assert.equal((await call(b,'invitation',{id:inv.data.id})).ok,true);
   assert.equal((await call(b,'joined',{id:inv.data.id})).error,'room_membership');
   rooms.get('ABC123').slots.blue=null;
   assert.equal((await call(a,'invite',{target:B,code:'ABC123'})).error,'room_membership');
   assert.equal((await call(b,'messages',{target:A,before:'bad'})).error,'invalid');
  }finally{a.disconnect();b.disconnect();stranger.disconnect();await io.close();await new Promise(r=>server.close(r));}
 });
});
