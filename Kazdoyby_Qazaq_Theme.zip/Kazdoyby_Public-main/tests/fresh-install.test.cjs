const {test}=require('node:test'),assert=require('node:assert/strict');
const {PGlite}=require('@electric-sql/pglite');
const fs=require('node:fs'),path=require('node:path');
const sql=name=>fs.readFileSync(path.join(__dirname,'../supabase',name),'utf8');
const A='11111111-1111-4111-8111-111111111111',B='22222222-2222-4222-8222-222222222222';
test('A fresh Supabase installation supports game writes, RPCs and private browser roles',async t=>{
 const db=new PGlite();t.after(()=>db.close());
 // Only Supabase-owned prerequisites are mocked; all game tables come from shipped SQL.
 await db.exec('create role anon;create role authenticated;create role service_role bypassrls;create schema auth;create table auth.users(id uuid primary key);');
 const files=['000_base_schema.sql','001_social.sql','002_arena.sql','003_room_seating_avatars.sql','004_tournament_reliability.sql'];
 for(const f of files)await db.exec(sql(f));
 await db.query('insert into auth.users(id) values($1),($2)',[A,B]);
 const asServer=fn=>db.transaction(async tx=>{await tx.exec('set local role service_role');return fn(tx);});
 const rpc=(actor,action,payload={})=>asServer(async tx=>(await tx.query('select kaz_tournament($1,$2,$3::jsonb) data',[actor,action,JSON.stringify(payload)])).rows[0].data);
 await asServer(async tx=>{
  const player=(await tx.query("insert into players(auth_user_id,client_id,email,name) values($1,'shared-browser-id','alice@test.invalid','Alice') returning *",[A])).rows[0];
  assert.equal(player.rating,1000);
  await tx.query("insert into players(auth_user_id,client_id,email,name) values($1,'shared-browser-id','bob@test.invalid','Bob')",[B]);
  const match=(await tx.query("insert into matches(room_code,game_mode,rating_mode,status) values('NEWDB1','teams','tournament','playing') returning *")).rows[0];
  await tx.query("insert into match_players(match_id,player_id,player_name,color,player_type) values($1,$2,'Alice','blue','human')",[match.id,player.id]);
  await tx.query("insert into match_players(match_id,player_name,color,player_type,bot_level) values($1,'Bot','black','ai','hard')",[match.id]);
  await tx.query("insert into moves(match_id,move_number,player_color,from_square,to_square,captures) values($1,1,'blue','C1','D2',$2)",[match.id,JSON.stringify({count:0,route:['C1','D2']})]);
  await tx.query("update matches set status='finished',winner='blue-black',finished_at=now() where id=$1",[match.id]);
  await tx.query("update match_players set result='win' where match_id=$1",[match.id]);
  await tx.query('select kaz_social($1,$2,$3::jsonb)',[A,'init',JSON.stringify({name:'Alice'})]);
  await tx.query('select kaz_set_avatar($1,$2::jsonb,$3)',[A,JSON.stringify({type:'icon',value:'crown'}),'Alice']);
 });
 let cup=await rpc(A,'create',{name:'New database cup',capacity:2,time:180,aiLevel:'hard'});
 await rpc(B,'join',{id:cup.id});cup=await rpc(A,'start',{id:cup.id});
 const match=cup.matches[0];
 await asServer(tx=>tx.query('select kaz_tournament_room($1,$2,$3,$4::jsonb)',[A,match.id,'bind',JSON.stringify({room:'CUP123'})]));
 cup=await rpc(match.player1,'result',{match:match.id,room:'CUP123',winner:match.player1});
 assert.equal(cup.status,'completed');assert.equal(cup.ai_level,'hard');
 await rpc(B,'hide',{id:cup.id});await rpc(A,'delete',{id:cup.id});
 for(const role of ['anon','authenticated'])for(const table of ['players','matches','match_players','moves']){
  await assert.rejects(db.transaction(async tx=>{await tx.exec('set local role '+role);await tx.query('select * from '+table);}),/permission denied/);
 }
 const reports=await db.exec(sql('verify_install.sql'));
 assert.equal(reports[0].rows.length,13);
 assert.ok(reports[0].rows.every(r=>r.present&&r.rls_enabled&&r.server_access&&!r.anon_access&&!r.browser_access));
 assert.ok(reports[1].rows.every(r=>r.present));assert.equal(reports[2].rows.length,5);
 // Reapplying all migrations must retain real game records.
 for(const f of files)await db.exec(sql(f));
 assert.equal((await db.query('select count(*)::int n from players')).rows[0].n,2);
 assert.equal((await db.query('select count(*)::int n from moves')).rows[0].n,1);
});
test('Bootstrap refuses to overwrite an unrelated existing game schema',async t=>{
 const db=new PGlite();t.after(()=>db.close());
 await db.exec("create schema auth;create table auth.users(id uuid primary key);create table players(note text);insert into players values('keep me');");
 await assert.rejects(db.exec(sql('000_base_schema.sql')),/Existing game tables detected/);
 await db.exec('rollback');assert.equal((await db.query('select note from players')).rows[0].note,'keep me');
});
